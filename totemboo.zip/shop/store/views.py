import itertools

from django.shortcuts import render, redirect
from .models import Product, Category
from django.views.generic import ListView, DetailView
from random import randint

from .forms import *
from django.contrib.auth import logout, login
from django.contrib import messages


# Create your views here.

class ProductList(ListView):
    model = Product
    context_object_name = 'categories'
    extra_context = {
        'title': 'TOTEMBO: Главная страница'
    }
    template_name = 'store/product_list.html'

    def get_queryset(self):
        categories = Category.objects.filter(parent=None)
        return categories

    # context = {
    #     'categories': categories
    # }


class CategoryView(ListView):
    model = Product
    context_object_name = 'products'
    template_name = 'store/category_page.html'

    def get_queryset(self):
        main_category = Category.objects.get(slug=self.kwargs['slug'])
        subcategories = main_category.subcategories.all()
        data = []
        for category in subcategories:
            products = category.products.all()
            for product in products:
                data.append(product)
        return data


class ProductDetail(DetailView):
    model = Product
    context_object_name = 'product'

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        product = Product.objects.get(slug=self.kwargs['slug'])
        context['title'] = f'Товар: {product.title}'

        products = Product.objects.all()  # [10]
        data = []
        for i in range(4):  # 0 # 0
            random_index = randint(0, len(products) - 1)
            p = products[random_index]
            if p not in data:
                data.append(p)
        context['products'] = data
        context['reviews'] = Review.objects.filter(product__slug=self.kwargs['slug'])

        if self.request.user.is_authenticated:
            context['review_form'] = ReviewForm()

        return context


def login_registration(request):
    context = {
        'title': 'Войти или зарегистрироваться !',
        'login_form': LoginForm(),
        'registration_form': RegistrationForm()
    }

    return render(request, 'store/login_registration.html', context)


def user_login(request):
    form = LoginForm(data=request.POST)
    if form.is_valid():
        user = form.get_user()
        login(request, user)
        return redirect('product_list')
    else:
        messages.error(request, 'Не верное имя пользователя или пароль !')
        return redirect('login_registration')


def user_logout(request):
    logout(request)
    return redirect('product_list')


def register(request):
    form = RegistrationForm(data=request.POST)
    if form.is_valid():
        user = form.save()
        messages.success(request, 'Аккаунт успешно создан. Войдите в аккаунт !')
    else:
        for field in form.errors:
            messages.error(request, form.errors[field].as_text())
    return redirect('login_registration')


def save_review(request, product_id):
    form = ReviewForm(data=request.POST)
    if form.is_valid():
        review = form.save(commit=False)
        review.author = request.user
        review.product_id = product_id
        review.save()
    else:
        pass

    product = Product.objects.get(pk=product_id)
    return redirect('product_detail', product.slug)


def save_favourite_product(request, product_slug):
    user = request.user if request.user.is_authenticated else None
    product = Product.objects.get(slug=product_slug)
    favorite_products = FavouriteProducts.objects.filter(user=user)
    if user:
        if product in [i.product for i in favorite_products]:
            fav_product = FavouriteProducts.objects.get(user=user, product=product)
            fav_product.delete()
        else:
            FavouriteProducts.objects.create(user=user, product=product)

    next_page = request.META.get('HTTP_REFERER', 'product_list')
    return redirect(next_page)


class FavouriteProductsView(ListView):
    model = FavouriteProducts
    context_object_name = 'products'
    template_name = 'store/favourite_products.html'

    def get_queryset(self):
        user = self.request.user
        favs = FavouriteProducts.objects.filter(user=user)
        products = [i.product for i in favs]
        return products


def save_mail(request):
    email = request.POST.get('email')
    user = request.user if request.user.is_authenticated else None
    try:
        if email:
            Mail.objects.create(mail=email, user=user)
            next_page = request.META.get('HTTP_REFERER', 'product_list')
            return redirect(next_page)
    except:
        return redirect('product_list')


def send_mail_to_customers(request):
    from shop import settings
    from django.core.mail import send_mail

    if request.method == 'POST':
        text = request.POST.get('text')
        mail_list = Mail.objects.all()

        for email in mail_list:
            mail = send_mail(
                subject='У нас новая акция !',
                message=text,
                from_email=settings.EMAIL_HOST_USER,
                recipient_list=[email],
                fail_silently=True
            )
            print(f'Отправлено ли сообщение на почту {email} ? - {bool(mail)}')
    else:
        pass
    return render(request, 'store/send_mail.html')